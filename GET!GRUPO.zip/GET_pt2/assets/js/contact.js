// Cria uma função para aplicar a máscara de telefone
function formatarTelefone(InputContact) {
    var telefone = InputContact.value.replace(/\D/g, ''); // Remove caracteres não numéricos
    var tamanhoMaximo = 15;

    // Formata o número de telefone com a máscara desejada
    if (telefone.length <= 2) {
        InputContact.value = telefone;
    } else if (telefone.length <= 6) {
        InputContact.value = '(' + telefone.substring(0, 2) + ') ' + telefone.substring(2);
    } else if (telefone.length <= 10) {
        InputContact.value = '(' + telefone.substring(0, 2) + ') ' + telefone.substring(2, 6) + '-' + telefone.substring(6);
    } else {
        InputContact.value = '(' + telefone.substring(0, 2) + ') ' + telefone.substring(2, 7) + '-' + telefone.substring(7, tamanhoMaximo);
    }

    // Limita o número de caracteres do campo
    if (telefone.length > tamanhoMaximo) {
        InputContact.value = InputContact.value.slice(0, tamanhoMaximo);
    }
}

// Obtém o campo de entrada de telefone
var InputContact = document.getElementById('InputContact');

// Adiciona um ouvinte de evento de entrada ao campo de entrada de telefone
InputContact.addEventListener('input', function() {
    formatarTelefone(InputContact);
});
