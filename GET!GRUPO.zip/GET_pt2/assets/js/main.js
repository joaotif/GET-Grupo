import { initScrollReveal } from "../js/scrollReveal.js";
import { typeWrite } from "./typeWrite.js";
import { menu } from "./menu.js";
import { contato } from "./contact.js"

menu();
initScrollReveal();
contato();
typeWrite(document.querySelector(".typewriter"));