document.addEventListener("DOMContentLoaded", function() {
    const text = "Se você busca uma plataforma completa e integrada para gerir o seu negócio, conte conosco para ajudá-lo a alcançar seus objetivos.";
    const typingTextElement = document.getElementById("typewriter");

    let index = 0;

    function typeLetter() {
        if (index < text.length) {
            typingTextElement.textContent += text[index];
            index++;
            setTimeout(typeLetter, 30); 
        }
    }

    typeLetter();
});