import ScrollReveal from 'scrollreveal';

ScrollReveal().reveal('.delayMediumReveal', { delay: 300, interval: 200 });
ScrollReveal().reveal('.delayLargeReveal', { delay: 500, interval: 300 });
ScrollReveal().reveal('.delayExtraBigReveal', { delay: 700, interval: 400 });
ScrollReveal().reveal('.intervalCardReveal', { interval: 300 });

ScrollReveal().reveal('.nav-list', { delay: 300, origin: 'top', distance: '50px', opacity: 0 });
ScrollReveal().reveal('.mobile-menu', { delay: 300, origin: 'top', distance: '50px', opacity: 0 });
ScrollReveal().reveal('.faixaGetImg', { delay: 300, origin: 'bottom', distance: '50px', opacity: 0 });
