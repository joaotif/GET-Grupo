<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pega os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    // Monta o corpo do email
    $to = "batatinha@bbmail.com.br";
    $subject = $assunto;
    $body = "Nome: $nome\nEmail: $email\n\nMensagem:\n$mensagem";

    $headers = "From: $email";

    // Envia o email
    if (mail($to, $subject, $body, $headers)) {
        echo "Email enviado com sucesso.";
    } else {
        echo "Ocorreu um erro ao enviar o email.";
    }
} else {
    echo "Método de requisição inválido.";
}
?>